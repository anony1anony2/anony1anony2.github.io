# Anonymous Implementation of Submission #10210


## Setup
### Requirements

(1) Install requirements

```shell
pip install -r requirements.txt
```

(2) Install wavelet libraries

- [pytorch_wavelets](https://github.com/fbcotter/pytorch_wavelets)
```shell
git clone https://github.com/fbcotter/pytorch_wavelets
cd pytorch_wavelets
pip install .
```
- [PyWavelets](https://pywavelets.readthedocs.io/en/latest/install.html)
```shell
pip install PyWavelets
```

## Usage

The following command will run "train & inference" at the same time:

```bash
accelerate launch train_inference.py --config configs/man_skate.yml
```


## Hyperparameters

- `ld_global`: Weight for global motion alignment ($\lambda_{g}$ in the paper). <i>Default `0.4`</i>

- `ld_local`: Weight for local motion refinement ($\lambda_{l}$ in the paper). <i>Default `0.2`</i>

- `num_levels`: Number of levels in discrete wavelet transform. <i>Default `2` for 8-frames input video, `3` for 16-frames input video</i>

- `ld_levels`: Weight for the alignment of each wavelet coefficients. <i>Default: `[1]*(num_levels+1)`</i>
